const serverless = require('serverless-http');
const cors = require('cors')
module.exports.api = serverless(app)